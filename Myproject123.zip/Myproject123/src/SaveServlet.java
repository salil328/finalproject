import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String x=request.getParameter("id");
		String name=request.getParameter("name");
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String email=request.getParameter("email");
		String country=request.getParameter("country");
		String address=request.getParameter("address");
		String aadhar=request.getParameter("aadhaar");
		String pan=request.getParameter("pan");
		String policy=request.getParameter("policy");
		
		Emp e=new Emp();
		e.setId(Long.parseLong(x));
		e.setName(name);
		e.setFname(fname);
		e.setLname(lname);
		e.setEmail(email);
		e.setCountry(country);
		e.setAddress(address);
		e.setAadhar(aadhar);
		e.setPan(pan);
		e.setPolicy(policy);
		
		
		int status=EmpDao.save(e);
		if(status>0){
			out.print("<p>Record saved successfully!</p>");
			request.getRequestDispatcher("checkout.jsp").include(request, response);
		}else{
			out.println("Sorry! unable to save record");
		}
		
		out.close();
	}

}
